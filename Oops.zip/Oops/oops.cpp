#include <bits/stdc++.h>
using namespace std;
#include "student.cpp"

int main() {
	char name[] = "abcd";
	student s1(20, name);
	s1.display();

	name[0] = 'X';
	student s2(18, name);
	s2.display();
	s1.display();
	return 0;
}
