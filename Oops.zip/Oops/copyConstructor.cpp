#include<iostream>
using namespace std;
class copyObj {
	int x = 0, y = 0;
	public:
	copyObj() { cout << "Default Constructor Called! "; print(); }
	copyObj(int x1, int y1) {
		cout << "Paramertized Constructor Called! ";
		x = x1;
		y = y1;
		print();
	}
	copyObj(const copyObj &obj1) {
		cout << "Copy Constructor Called! ";
		x = obj1.x;
		y = obj1.y;
		print();
	}
	void print() { cout << "x: " << x << " y: " << y << endl; }
};
int main() {
	copyObj ob;
	copyObj ob1(10, 20);
	copyObj ob2 = ob1;
	return 0;
}
