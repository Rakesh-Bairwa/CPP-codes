#include<bits/stdc++.h>
using namespace std;
class A {	
	public:
		A() { cout << "A-Constructor\n"; }
	private:
	int x;
};
class B : A {}; // No user defined constructor --> default don't have cout
class C : A {
	public:
		C() { cout << "C-Constructor\n"; }
};
class D {
	public:
		D() {cout << "D-Constructor\n"; }
	private:
		cout << "Calling nested stuff first --then--> ";
		A a;
};
int main() {
	B b; // Call B's parent(A) Constructor ---Then---> B's Constructor
	C c; // parent's first : Call A's Constructor --then--> C's Const.
	D d; // Call A's Constructor --then--> D's Constructor
	
	cout << "Expected : A-->A-->C-->A-->D" << endl;
	return 0;
}
