#include<iostream>
using namespace std;
class copyObj {
        public:
        copyObj(const char* str="\n") {cout << "Default Constructor Called!\n";}
	copyObj(const copyObj & obj) {cout << "Copy Constructor Called\n";}
};
int main() {
	// Here compiler looking for 1-parametrer constructor so it willn't
	// run copy constructor & run default
	// old compiler internal working of this below line is :
	// copyObj x = copyObj("copy me"); ---> Copy constructor used
	// whereas new compiler so it this way :
	// copyObj x("copy me"); ----> No copy involved --> parameterized
	// constructor called.
	copyObj x = "copy me";
	return 0;
}	
