#include <bits/stdc++.h>
using namespace std;
int main() {
//using min-heap & adjacency list we can achieve Time : (E+V).logV & Space O(E)
//where as using adjacency matrix & a loop for find min Time = Space = O(V^2)
        int v, e, x, y;
        cout << "Enter vertices & edges : ";
        cin >> v >> e;
        vector<vector<int>> adj(v, vector<int>(v, 0));
        for (int i = 0; i < e; i++) {
                cout << "Enter vertices b/w them we've edge : ";
                cin >> x >> y;
                cout << "Enter weight of that edge : ";
                cin >> adj[x][y];
                adj[y][x] = adj[x][y];
        }
        vector<bool> visited(v, 0);
        vector<int> weight(v, INT_MAX);
	weight[0] = 0; // start from 0th node
        vector<int> parent(v, -1);
// PRIM'S ALGO :  Time : O(V^2) & space : O(V^2)
        for (int i = 0; i < v; i++) { // work for all vertices
                int wei = INT_MAX, loc = -1;
                for (int j = 0; j < v; j++){//find min weight & procced with it
			// We need min. n-times => using min-heap is better
                        if (!visited[j] && weight[j] < wei) {
                                wei = weight[j];
                                loc = j;
                        }
                }
		if (loc >= 0) visited[loc] = true; // mark vertex with weight
                for (int k = 0; k < v; k++) { // travel all unvisited neighbors
			// Using adjcaceny list this time & space both will be reduced
			if (adj[loc][k] && !visited[k]) {
				// update parent & weight
				if (weight[k] > adj[loc][k]) {
					weight[k] = adj[loc][k];
					parent[k] = loc;
				}
			}
		}
        }
// Printing
        cout << "\nMST\n";
	cout << "vertex-i  vertex-j  weight\n";
	// printing from 1 coz MST will have v-1 edges only
	for (int i = 1; i < v; i++) {
		if (parent[i] < i)
		cout << parent[i] <<"\t     "<< i <<"\t      "<< weight[i] << endl;
		else 
		cout << i <<"\t     "<< parent[i] <<"\t      "<< weight[i] << endl;
        }
	cout << endl;
        return 0;
}

