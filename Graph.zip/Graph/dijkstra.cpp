#include <bits/stdc++.h>
using namespace std;
/*
 * Time : O(V^2) & Space : O(N^2)
 * if we use adjacency list then Space : O(V + E) and Time : O((V + E)^2)
 * if we used min-heap for finding minVertex then Time : O(v + E).logV
*/
int minDist(vector<bool>&visited, vector<int>&distance) {
	int minVertex = -1;
	for (int i = 0; i < distance.size(); i++)
		if (!visited[i] && (minVertex == -1 || distance[i] < distance[minVertex])) 
			minVertex = i;
	return minVertex;
}
void dijkstra(vector<vector<int>>&adj, vector<bool>&visited, vector<int>&distance) {
	// Time : O(V) <--- loop
	for (int i = 0; i < adj.size() - 1; i++) { // last vertex k adjacent already visited hoge
		int vertex = minDist(visited, distance); // Time : O(V)
		visited[vertex] = true;
		for (int j = 0; j < adj.size(); j++) { //Time : O(V)
			if (adj[vertex][j] && !visited[j]) {
				int dist = distance[vertex] + adj[vertex][j];
				if (dist < distance[j]) distance[j] = dist;
			}
		}
	}
	cout << "\n**** MST after dijkstra algorithmn ****\n";
	for (int i = 1; i < distance.size(); i++) //we set starting node distance = 0
		cout << i << " : " << distance[i] << endl;
}
int main() {
	int v, e, x, y, weight;
	cout << "Enter vertices & edges : ";
	cin >> v >> e;
	vector<vector<int>> adj(v, vector<int>(v, 0));
	for (int i = 0; i < 7; i++) {
		cout << "Enter 2 vertices b/w them we've edge & weight : ";
		cin >> x >> y >> weight;
		adj[x][y] = weight;
		adj[y][x] = weight;
	}
	vector<bool> visited(v,0);
	vector<int> distance(v,INT_MAX);
	distance[0] = 0;
	dijkstra(adj, visited, distance);
	return 0;
}
