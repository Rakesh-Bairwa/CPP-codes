#include <iostream>
#include <queue>
using namespace std;

// DFS for single component
void dfsPrint(int **edges, int n, int sv, bool *visited) { 
	// sv = starting vertex
	cout << sv << " ";
	visited[sv] = 1;
	for (int i = 0; i < n; i++) {
		if (i == sv) continue;
		if (edges[sv][i] == 1) {
			if (visited[i]) continue;
			else dfsPrint(edges, n, i, visited);
		}
	}
}
// BFS for single component
void bfsPrint(int **edges, int n, int sv, bool *visited) {
	queue<int> q;
	q.push(sv);
	while (q.size()) {
		int j = q.front(); q.pop();
		visited[j] = 1;
		cout << j << " ";
		for (int i = 0; i < n; i++) {
			if (edges[j][i] && !visited[i]) {
				q.push(i);
				visited[i] = 1;
			}
		}
	}
}
// For n-components in graph
void DFS(int **edges, int n) {
	bool *visited = new bool[n];
	for (int i = 0; i < n; i++) visited[i] = 0;
	for (int i = 0; i < n; i++) {
		if (visited[i]) continue;
		dfsPrint(edges, n, i, visited);
	}
	delete [] visited;
}
// For n-components in graph
void BFS(int **edges, int n) {
	bool *visited = new bool[n];
        for (int i = 0; i < n; i++) visited[i] = 0;
        for (int i = 0; i < n; i++) {
                if (visited[i]) continue;
                dfsPrint(edges, n, i, visited);
        }
        delete [] visited;
}
int main() {
	int e, n;
	cout << "Enter vertex : "; cin >> n;
	cout << "Enter edges : "; cin >> e;
	int **edges = new int*[n];
	// creating a grid of all zeros
	for (int i = 0; i < n; i++) {
		edges[i] = new int[n];
		for (int j = 0; j < n; j++) {
			edges[i][j] = 0;
		}
	}
	// Input grid data
	for (int i = 0; i < e; i++) {
		int f, s;
		cout << "Enter 2-vertices for an edge : "; cin >> f >> s;
		edges[f][s] = 1, edges[s][f] = 1;
	} 
	cout << endl << "GRID  : \n";
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			cout << edges[i][j] << " ";
		}
		cout << endl;
	} cout << endl;
	cout << "\nDFS : ";
	DFS(edges, n); cout << endl;
	
	cout << "\nBFS : ";
	BFS(edges, n); cout << endl;

	for (int i = 0; i < n; i++) delete [] edges[i];
	delete [] edges;
}
