class student {
	int age;
	char *name;
public :
	student(int age, char *name) {
		this -> age = age;
		// shallow copy : we're copying just reference
		// this -> name = name;
		
		// deep copy 
		// strlen don't count null char
		// this -> name pointing to new array address having garbage
		this -> name = new char[strlen(name) + 1]; // 1 for '\0'
		strcpy(this -> name, name);
	}
	void display() {
		cout << "Age : " << age << " Name : " << name << endl;
	}
};
