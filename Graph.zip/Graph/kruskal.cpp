#include <bits/stdc++.h>
using namespace std;
class kru {
public:
	int vertex1;
	int vertex2;
	int weight;
};
bool comp(kru x, kru y) {return x.weight < y.weight;}
int find_parent(int v, int parent[0]) {
	if (v == parent[v]) return v;
	return find_parent(parent[v], parent);
}
void kruskal(int v, int e, kru input[0], kru output[0]) {
// Time : O(E.logE + EV)
	int i = 0, count = 0;
	int parent[v];// (Parent) Time : O(V) & Space : O(V)
	for(int i = 0; i < v; i++) parent[i] = i;
	sort(input, input + e, comp); // Time : O(E.logE)
	while(count != v - 1) { // Time : O(E)
		kru temp = input[i];
		// (find_parent) Time : O(V) via union find
	        int source = find_parent(input[i].vertex1, parent);
        	int dest = find_parent(input[i].vertex2, parent);
  	        if(source != dest) {
        	        output[count] = temp;
              		parent[source] = dest;
	                count++;
	    	}
            	i++;
	}
}
void print(int v, int e, kru input[0], kru output[0]) {
	for (int i = 0; i < e; i++) {
                cout << i <<" : " << input[i].vertex1 << " ";
                cout << input[i].vertex2 << " " << input[i].weight;
                if (i < v - 1) {
                cout << "   |   "  << output[i].vertex1 << " ";
                cout << output[i].vertex2 << " " << output[i].weight << endl;
                }
        } cout << endl;
}
void take_input(int e, kru input[0]){
	for (int i = 0; i < e; i++) {
                cout << "Enter 2 vertices & weight : ";
                cin >> input[i].vertex1;
                cin >> input[i].vertex2;
                cin >> input[i].weight;
        }
}
int main() {
	/*
	 * Now SPACE : O(E + V)
	 * And Time : O(E.logE + EV)
	 * 
	 * In worst case "E = V*V"
	 * 
	 * Using "Union-find by rank & path compression" we can make sight 
	 * improvement in time compelexity. It's obvious we can't remove sorting.
	 * Using this method we achieve Time E.logV instead of EV =>
	 * Worst Time will become : O(E.logE) & Space = O(E + V)
	 */
	int v, e;
	cout << "Enter no. of vertices : "; cin >> v;
	cout << "Enter No. of edges : "; cin >> e;

	// (defination) Time : O(1) & Space : O(E)
	kru input[e];
	
	// (take_input) Time : O(E) & Space : O(1)
	take_input(e, input);
	
	// (Kruskal) Time : O(E.logE + EV) & Space : O(V)
	kru output[v - 1];
      	kruskal(v, e, input, output);
	
	// (print) Time : O(E) & Space : O(1)
	print(v, e, input, output);
	return 0;
}
