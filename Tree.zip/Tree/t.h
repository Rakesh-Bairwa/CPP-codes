#include <vector>
using namespace std;

template<typename T>
class TreeNode {
public :
	T data;
	vector<TreeNode*>children;
	TreeNode(T data) {
		this->data = data;
	}
	~TreeNode() {
// destructor will delete all child's(or entire subtree) for the given root.
// then it will delete root too. 
	for (int i = 0; i < children.size(); i++) {
		cout << children[i]->data << "deleted!" << endl;
		delete children[i];
	}
	}
};
