#include <iostream>
#include <queue>
#include "t.h"
TreeNode<int>* bfsInput() {
	int rootData; cout << "Enter root data: ";
	cin >> rootData;
	TreeNode<int>* root = new TreeNode<int>(rootData);
	queue<TreeNode<int>*> pendingNode;
	pendingNode.push(root);
	while (!pendingNode.empty()) {
		TreeNode<int>* front = pendingNode.front();
		pendingNode.pop();
		cout << "Enter no. of childrens of " << front->data << " : ";
		int total_child;
		cin >> total_child;
		for (int i = 0; i < total_child; i++) {
			int childData;
			cout << i << "th child data : ";
			cin >> childData;
			TreeNode<int> *child = new TreeNode<int>(childData);
			front->children.push_back(child);
			pendingNode.push(child);
		}
	}
	return root;
}
TreeNode<int> *dfsInput() {
	int rootData, total_child; 
	cout << "Enter data : "; 
	cin >> rootData;
	TreeNode<int> *root = new TreeNode<int>(rootData); 
	cout << "No. of childs of " << rootData << " : ";
	cin >> total_child;

	for(int i = 0; i < total_child; i++) {
		TreeNode<int> *child = dfsInput();
		root->children.push_back(child);
	}
	return root;
}
void dfsPrint(TreeNode<int> *root) {
	cout << root->data << ", ";
	for (int i = 0; i < root->children.size(); i++) {
		dfsPrint(root->children[i]);
	}
}
void bfsPrint(TreeNode<int> *root) {
	cout << root->data<< " : ";
	for (int i = 0; i < root->children.size(); i++) {
		cout << root->children[i]->data << " ,";
	}
	cout << endl;
	for (int i = 0; i < root->children.size(); i++) {
		bfsPrint(root->children[i]);
	}
}
int main() {
	//TreeNode<int> *root = bfsInput();
	//bfsPrint(root);
	TreeNode<int> *root = dfsInput();
	dfsPrint(root);
	return 0;
}

